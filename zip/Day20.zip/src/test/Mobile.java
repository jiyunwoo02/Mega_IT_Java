package test;

public class Mobile {
	private String name;
	private String telecom;
	private int price;
	
	Mobile(){};
	
	Mobile(String name, String telecom, int price) {
		this.name = name;
		// �̷��� �ۼ��ϴ� �͵� �����ϴ�
		// this.set_name(name);
		this.telecom = telecom;
		
		this.set_price(price);
	}
	
	public String get_name() {
		return this.name;
	}
	public String get_telecom() {
		return this.telecom;
	}
	public int get_price() {
		return this.price;
	}
	
	private void set_name(String name) {
		this.name = name;
	}
	public void set_telecom(String telecom) {
		this.telecom = telecom;
	}
	public void set_price(int price) {
		if (price < 400000) {
			System.out.println("�޴��� �ּҰ����� 400,000");
			this.price = 400000; // ��������!
			return;
		}
		this.price = price;
	}

	void info() {
		System.out.printf("%s\t%s\t%d", this.name, this.telecom, this.price);
	}
}
