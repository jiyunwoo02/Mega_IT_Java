package forloop;

public class Test01 {

	public static void main(String[] args) {
		/*
		 * ���� 1)
		 * #
		 * ##
		 * ###
		 */
		for(int i = 0; i < 3 ; i++) {
			for(int j = 0; j <= i; j++) {
				System.out.print("#");
			}
			System.out.println();
		}
		/*
		 * ���� 2)
		 * ###
		 * ##
		 * #
		 */
		for(int i=0;i<3;i++) {
			for(int j=2;j>=i;j--) {
				System.out.print("#");
			}
			System.out.println();
		}
		 /* ���� 3)
		 * @##
		 * @@#
		 * @@@
		 */
		for(int i=0;i<3;i++) {
			for(int j=0;j<=i;j++) {
				System.out.print("@");
			}
			for(int j=1;j>=i;j--) {
				System.out.print("#");
			}
			System.out.println();
		}
		 /* ���� 4)
		 *   #
		 *  ###
		 * #####
		 */
		for(int i=0;i<3;i++) {
			for(int j=0;j<2-i;j++) {//int j=1;j >= i;j--
				System.out.print(" ");
			}
			for(int j=0;j<1+2*i;j++) {
				System.out.print("#");
			}
			System.out.println();
		}
		
		int k = 0;
		for(int i=0;i<3;i++) {
			for(int j=2;j>i;j--) {
				System.out.print(" ");
			}
			for(int j=0;j<=k;j++) {
				System.out.print("#");
			}
			k+=2;
			System.out.println();
		}

	}

}
