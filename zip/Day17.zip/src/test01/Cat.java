package test01;

public class Cat extends Animal {

	private String name;
	public Cat() {}
	public Cat(String name) {
		super(name);
	}
	
	public void bark() {
		System.out.println("�߿�");
	}
	public void eat() {
		System.out.println("����");
	}
}
