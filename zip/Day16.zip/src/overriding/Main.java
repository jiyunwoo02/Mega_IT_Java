package overriding;

public class Main {
	public static void main(String[] args) {
		Child c = new Child();
		c.method();
	}
}
